#include <stdlib.h>
#include <stdio.h>
//nro USP 7569223

typedef struct{
        char nome [60];
        char email[60];
        long int nrusp;
        long int tel;
        }aluno;
typedef struct {
        char titulo [100];
        char autor [60];
        int isbn;
        char editora [60];
        int ano;
        int edicao;
        int ncopias;
        }livro;

typedef union{
        aluno Aluno;
        livro Livro;
        } elem;


typedef struct bloco {
        elem info;
        struct bloco *prox;
} no;

typedef struct {
        no *inicio, *fim;
} Banco;

void cadastraAluno (elem *a);
void cadastraLivro (elem *a);
void cria(Banco *L);
void inserir(Banco *L, elem *X, int *erro);
int retiraLivro(Banco *L,int isbn);
int retornaLivro(Banco *L,int isbn);
void DeletaLivro(Banco *L,int isbn, int *erro);
void DeletaAluno(Banco *L,int nrusp, int *erro);
int imprimeLivro(Banco *L,int isbn);
