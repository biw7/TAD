//nro USP 7569223
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define tam 1000


typedef struct {
        char nome [30];
        int numero;
        int tel;
        short usado;
                       
        } Aluno;


typedef struct {
         char titulo [30];
         int isbn;
         int ncopias;
         short usado;
        } Livro;


typedef struct {
int isbn;
int nrusp;
short usado;
}Fila;

typedef struct {
int isbn;
int nrusp;
short usado;
}ListaEmprestimo;

void iniciaLivro (Livro vet2[]) ;
void iniciaFila(Fila vetFila[]);
void iniciaListaEmprestimo (ListaEmprestimo vetLista[]);
void cadastraAluno (Aluno *a);
void cadastraLivro (Livro *l);
void cadastraFila (Fila *F,int isbn,int nrusp);
void cadastraListaEmprestimo (ListaEmprestimo *L,int isbn,int nrusp);
int insereCadAluno (Aluno vet[],Aluno a);
int insereCadLivro (Livro vet2[],Livro l);
int insereListaEmprestimo(ListaEmprestimo vetLista[],ListaEmprestimo L);
int insereFila(Fila vetFila[],Fila F);
void imprimeAluno (Aluno vet[]);
void imprimeLivro (Livro vet2[]);
void imprimeFila (Fila vetFila[],int isbn);
void imprimeLista (ListaEmprestimo vetLista[],int isbn); 
void imprimeListaAluno (ListaEmprestimo vetLista[],int nro);
int checaFila (Fila vetFila[],int isbn);
void retiraLista (ListaEmprestimo vetLista[],int isbn,int nrusp);
void retiraFila (Fila vetFila[],int isbn,int nrusp);
int buscaLivroCod (Livro vet2[], int isbn);
int buscaAlunoCod (Aluno vet[], int nrusp);
int imprimeBuscaLivro (Livro vet2[], int j);
int emprestaLivro (Livro vet2[], int isbn,int nrusp);
int retornaLivro (Livro vet2[], int isbn,int nrusp);



