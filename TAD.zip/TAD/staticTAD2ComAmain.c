//nro USP 7569223
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define tam 1000
#include "StaticTAD2"



        
void iniciaAluno(Aluno vet[]) {
      int i;
      for (i = 0; i<tam; i++) {
          vet[i].usado = 0;
          }
       }

void iniciaLivro (Livro vet2[]) {
      int j;
      for (j = 0; j<tam; j++) {
          vet2[j].usado = 0;
          }
       }

void iniciaFila(Fila vetFila[]) {
      int i;
      for (i = 0; i<tam; i++) {
          vetFila[i].usado = 0;
          }
       }

void iniciaListaEmprestimo (ListaEmprestimo vetLista[]) {
      int j;
      for (j = 0; j<tam; j++) {
          vetLista[j].usado = 0;
          }
       }


void cadastraAluno (Aluno *a) {
      printf ("Nome:");
      scanf ("%s", (*a).nome);
      printf ("Numero:");
      scanf ("%d", &(*a).numero);
      printf ("Tel:");
      scanf ("%d", &(*a).tel);
      fflush (stdin);
      }
             
 void cadastraLivro (Livro *l) {
      printf ("Titulo:");
      scanf ("%s", (*l).titulo);
      printf ("ISBN:");
      scanf ("%d", &(*l).isbn);
      printf ("Copias:");
      scanf ("%d", &(*l).ncopias);
      fflush (stdin);
      }            
 
void cadastraFila (Fila *F,int isbn,int nrusp) {
      F->isbn = isbn;   
      F->nrusp = nrusp; 
           
 
}

void cadastraListaEmprestimo (ListaEmprestimo *L,int isbn,int nrusp) {
      L->isbn = isbn;           
      L->nrusp = nrusp;

      }            
  
 
             
int insereCadAluno (Aluno vet[],Aluno a) {
    int i;
    for (i=0; i<tam; i++) {
        if (vet[i].usado == 0){
                         vet[i] = a;
                         vet[i].usado = 1;
                      return 1;
                      }
                      }
                      return 0;
    }                
                      
 
 int insereCadLivro (Livro vet2[],Livro l) {
    int j;
    for (j=0; j<tam; j++) {
        if (vet2[j].usado == 0){
                         vet2[j] = l;
                         vet2[j].usado = 1;
                      return 1;
                      }
                      }
                      return 0;
    }  
 
       
                      
 
 int insereListaEmprestimo(ListaEmprestimo vetLista[],ListaEmprestimo L) {
    int j;
    for (j=0; j<tam; j++) {
        if (vetLista[j].usado == 0){
                         vetLista[j] = L;
                         vetLista[j].usado = 1;
                      return 1;
                      }
                      }
                      return 0;
    }    
  
  
  int insereFila(Fila vetFila[],Fila F) {
    int i;
    for (i=0; i<tam; i++) {
        if (vetFila[i].usado == 0){
                         vetFila[i] = F;
                         vetFila[i].usado = 1;
                      return 1;
                      }
                      }
                      return 0;
    }                            

void imprimeAluno (Aluno vet[]) {
      int i,cont = 0;
       
       for (i=0; i<tam; i++) {
           if (vet[i].usado == 1)
           { printf ("%s\n", vet[i].nome);
             printf ("%d\n", vet[i].numero);
             printf ("%d\n", vet[i].tel);
             printf ("\n");
             } 
             }

}

void imprimeLivro (Livro vet2[]) {
      int j,cont = 0;
       
       for (j=0; j<tam; j++) {
           if (vet2[j].usado == 1)
           { printf ("%s\n", vet2[j].titulo);
             printf ("%d\n", vet2[j].isbn);
             printf ("%d\n", vet2[j].ncopias);
             printf ("\n");
             } 
             }

}

void imprimeFila (Fila vetFila[],int isbn) {
      int i;
       
       for (i=0; i<tam; i++) {
           
           if (vetFila[i].isbn == isbn) {
            printf ("Aluno %d  ", vetFila[i].nrusp);
             
             
             } 
             }

}

void imprimeLista (ListaEmprestimo vetLista[],int isbn) {
      int j;
       
       for (j=0; j<tam; j++) {
           if (vetLista[j].usado == 1)
           { if (vetLista[j].isbn == isbn) {
             printf ("Aluno:%d ",vetLista[j].nrusp);
             }
             } 
             }
 printf ("\n");

}

void imprimeListaAluno (ListaEmprestimo vetLista[],int nro){
     int j;
       
       for (j=0; j<tam; j++) {
           if (vetLista[j].usado == 1)
           { if (vetLista[j].nrusp == nro) {
             printf ("ISBN:%d ",vetLista[j].isbn);
             }
             } 
             }
 printf ("\n");
     
     }

int checaFila (Fila vetFila[],int isbn) {
    int i;
    for (i=0; i<tam; i++) {
        if (vetFila[i].isbn == isbn) {
                        return 1;
                      }
                     
                       
                      }
        return -1;                
    }    




void retiraLista (ListaEmprestimo vetLista[],int isbn,int nrusp) {
int j;
for (j=0;j<tam;j++) {
if (vetLista[j].nrusp == nrusp)
{ if (vetLista[j].isbn == isbn) {
     vetLista[j].isbn =NULL ;
     vetLista[j].nrusp = NULL;
     vetLista[j].usado = 0;
     }
}
}

}

void retiraFila (Fila vetFila[],int isbn,int nrusp) {
int j;
for (j=0;j<tam;j++) {
if (vetFila[j].nrusp == nrusp)
{ if (vetFila[j].isbn == isbn) {
     vetFila[j].isbn =NULL ;
     vetFila[j].nrusp = NULL;
     vetFila[j].usado = 0;
     }
}
}

}
int buscaLivroCod (Livro vet2[], int isbn) {
     int j;
     for (j=0; j<tam;j++) {
         if (vet2[j].isbn==isbn){
                     return j;
         }
         } 
  return -1;
     }

int buscaAlunoCod (Aluno vet[], int nrusp) {
     int i;
     for (i=0; i<tam;i++) {
         if (vet[i].numero==nrusp){
                     return i;
         }
         } 
  return -1;
     }

int imprimeBuscaLivro (Livro vet2[], int j) {
     int loan;
      loan = vet2[j].ncopias;
     if ( j > -1)
     {
          if (vet2[j].usado == 1) 
          { printf ("%s\n",vet2[j].titulo);
            printf ("%d", vet2[j].ncopias); 
           
            } 
          }

  return loan;
}



int emprestaLivro (Livro vet2[], int isbn,int nrusp) {
     int j;
     for (j=0; j<tam;j++) {
         if (vet2[j].isbn==isbn){
         vet2[j].ncopias--;
          return j;
         }
         
         } 
  return -1;
     }


int retornaLivro (Livro vet2[], int isbn,int nrusp) {
     int j;
     for (j=0; j<tam;j++) {
         if (vet2[j].isbn==isbn){
         vet2[j].ncopias++;
          return j;
         }
         
         } 
  return -1;
     }



int main () {
 int op,aux,search,searchAluno,oploan,loan,opfila,check;
 int nro;
 
 Aluno n[tam];
 Aluno a;   
 Livro m[tam];
 Livro l;
 Fila f[tam];
 Fila fi;
 ListaEmprestimo list[tam];
 ListaEmprestimo li;
 iniciaAluno (n);
 iniciaLivro (m);   
 iniciaFila (f);
 iniciaListaEmprestimo (list);

 do {
     puts ("1.CadastraAluno\n2.CadastraLivro\n3.Busca Livro por Codigo\n4.RetornaLivro\n5.ImprimeFila\n6.ImprimeListaPorLivro\n7.ImprimeListaPorAluno\n8.RetiraFila(Empresta para o primeiro)\n");
     printf ("op:");
     scanf ("%d",&op);
     
     switch (op) {
            
              case 1:
                 cadastraAluno (&a);
                 insereCadAluno (n,a);
                 break;
              
              case 2:
                 cadastraLivro (&l);
                 insereCadLivro (m,l);
                 break;
              
              case 3: 
               printf ("ISBN:");
               scanf ("%d", &aux); 
               search= buscaLivroCod (m,aux);
               loan = imprimeBuscaLivro (m,search);
               printf ("\n");
               if (search == -1){ printf ("Livro nao disponivel no catalogo!\n");
               break; }
               
               else if (loan == 0) { printf ("Livro indisponivel\n"); 
                                printf ("Deseja entrar na fila?");
                                scanf ("%d", &opfila);
                                if (opfila == 1) {
                                    printf ("nro Aluno");
                                    scanf ("%d", &nro);
                                    cadastraFila (&fi,aux,nro);  
                                     insereFila (f,fi);     
                                           break;
                                           }
                                else
                                break; }
                                
               else if (loan >=1)
                {
               printf ("\nLivro Disponivel\n");
               printf ("%d copias\n", loan);
               printf ("Realiza emprestimo?");
               scanf ("%d", &oploan);
               if (oploan == 1) 
               { 
                 printf ("nro Aluno");
                 scanf ("%d", &nro);
                 searchAluno= buscaAlunoCod (n,nro);
                  if (searchAluno == -1) { printf ("Aluno nao encontrado!\n"); break; }
                  else {
                 loan = emprestaLivro (m, aux,nro);
                 cadastraListaEmprestimo (&li,aux,nro);
                 insereListaEmprestimo(list,li);
                  
                 break;
                 }
                 }
               else {break;}
               } 
                 
               
               else
               break;
              
                  
               case 4:
                  printf ("ISBN:");
                  scanf ("%d", &aux);
                  printf ("Nrusp: ");
                  scanf ("%d", &nro);
                  search= buscaLivroCod (m,aux);
                  if (search == -1) { printf ("Livro nao disponivel no catalogo!\n"); break;}
                   else {
                          loan = retornaLivro (m, aux,nro); 
                          retiraLista (list,aux,nro);           
                          check = checaFila (f,aux);
                          if (check == 1) {
                                    printf ("Existe fila de espera pelo livro! checar fila\n");
                                    }
                          
                        }
        
                    break;
        
        
               case 5:
                       printf ("ISBN:");
                       scanf ("%d", &aux);
                        search= buscaLivroCod (m,aux);  
                        check = checaFila (f,aux);
                        if (search == -1) { printf ("Livro nao disponivel no catalogo!\n"); break;}
                   
                      
                      else if (check == -1) {
                      printf ("Nao ha fila para esse isbn!\n"); 
                      break;
                      }
                      else if (check == 1)
                         { 
                         imprimeFila (f,aux);
                         printf ("\n");
                         break;
                         }
                       
               else        
               break;  
                         
               
               case 6:
                    printf ("ISBN:");
                       scanf ("%d", &aux);
                       search= buscaLivroCod (m,aux);  
                        
                        if (search == -1) { printf ("Livro nao disponivel no catalogo!\n"); break;}
                   
                   else {
                    imprimeLista (list,aux);
                    break;
                    }
                      break;
             
                case 7:
                     printf ("Nro USP:");    
                     scanf ("%d", &nro);
                     searchAluno= buscaAlunoCod (n,nro);
                  if (searchAluno == -1) { printf ("Aluno nao encontrado!\n"); break; }
                    else {
                        imprimeListaAluno (list,nro);
                        break;
                         }
                    
                    break;
                    
                
                case 8:
                     printf ("ISBN:");
                       scanf ("%d", &aux);
                        search= buscaLivroCod (m,aux);  
                        check = checaFila (f,aux);
                        if (search == -1) { printf ("Livro nao disponivel no catalogo!\n"); break;}
                   
                      
                      else if (check == -1){ printf ("Nao ha fila para esse isbn!\n");
                       break; 
                                   }
                      else if (check == 1)
                         { 
                         imprimeFila (f,aux);
                         printf ("\nNro Usp p/ emprestimo:");
                         scanf ("%d", &nro);
                         loan = emprestaLivro (m, aux,nro);
                         cadastraListaEmprestimo (&li,aux,nro);
                         insereListaEmprestimo(list,li);
                         retiraFila (f,aux,nro);
                         printf ("Livro emprestado para o nro usp %d, primeiro da fila.\n",nro);
                         break;
                         }
                       
                       else 
                      
                       break;  
                
                
                }
                   
        } while (op!=0);
    
    system ("PAUSE");
    return 0;
    }
