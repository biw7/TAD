//nro USP 7569223
#include <stdlib.h>
#include <stdio.h>
#define TAM 1000
#include "StaticTAD.h"

void cadastraAluno (elem *a) {
      printf ("Nome:");
      scanf ("%s", (*a).Aluno.nome);
      printf ("email:");
      scanf ("%s", (*a).Aluno.email);
      printf ("Numero:");
      scanf ("%d", &(*a).Aluno.nrusp);
      printf ("Tel:");
      scanf ("%d", &(*a).Aluno.tel);
      fflush (stdin);
      }
void cadastraLivro (elem *a) {
      printf ("Titulo:");
      scanf ("%s", (*a).Livro.titulo);
      printf ("Autor:");
      scanf ("%s",(*a).Livro.autor);
      printf ("ISBN:");
      scanf ("%d",&(*a).Livro.isbn);
      printf ("Editora:");
      scanf ("%s", (*a).Livro.editora);
      printf ("Ano:");
      scanf ("%d", &(*a).Livro.ano);
      printf ("Edicao:");
      scanf ("%d", &(*a).Livro.edicao);
      printf ("Numero de copias:");
      scanf ("%d", &(*a).Livro.ncopias);  
      fflush (stdin);
      }

      
 void cria(Banco *B) {
     int i;
     for (i=0;i<TAM-1;i++)
         B->itens[i].prox=i+1;
     B->itens[TAM-1].prox=-1;
     B->primeiro_vazio=0;
     B->ini=-1;
     B->fim=-1;
}





void getnode(Banco *B, int *pos) {
    if (B->primeiro_vazio!=-1) {
       *pos=B->primeiro_vazio;
       B->primeiro_vazio=B->itens[B->primeiro_vazio].prox;
       B->itens[*pos].prox=-1;
    }
    else *pos=-1;
}

int EstaVazio(Banco *B) {
    if (B->ini==-1)
       return(1);
    else return(0);
}

int EstaCheio(Banco *B) {
    if (B->primeiro_vazio==-1)
       return(1);
    else return(0);
}

void inserir (Banco *B, elem *x, int *erro) {
     int pos;
     if (EstaCheio(B))
        *erro=1;
     else {
          *erro=0;
          getnode(B,&pos);
          B->itens[pos].info=*x;
          B->itens[pos].prox=B->ini;
          B->ini=pos;
          if (B->fim==-1)
             B->fim=pos;
     }
}     

 int retiraLivro (Banco *B,int isbn) {
     int i;
     for (i=0;i<TAM-1;i++){
         if (B->itens[i].info.Livro.isbn == isbn){
            if (B->itens[i].info.Livro.ncopias == 0)
              {return 0;}
             
             else
             B->itens[i].info.Livro.ncopias --;
             }
            }
             return B->itens[i].info.Livro.ncopias;
             }
 
 
 
 void retornaLivro (Banco *B,int isbn) {
     int i;
     for (i=0;i<TAM-1;i++){
         if (B->itens[i].info.Livro.isbn == isbn){
            B->itens[i].info.Livro.ncopias ++;
             }
            
             }
 }


void imprimeLivro (Banco *B,int isbn) {
     int i;
     for (i=0;i<TAM-1;i++) {
         if (B->itens[i].info.Livro.isbn == isbn)
            { printf ("%s\n", B->itens[i].info.Livro.titulo);
              printf ("%d\n", B->itens[i].info.Livro.ncopias);
              
                                         }
                                         }
     
     }

void freenode(Banco *B, int *pos) {
    B->itens[*pos].prox=B->primeiro_vazio;
    B->primeiro_vazio=*pos;
}

void DeletaLivro(Banco *B, int isbn, int *erro) {
     int pos;
     if (EstaCheio(B))
        *erro=1;
     else {
          *erro=0;
          getnode(B,&pos);
          freenode(B,&pos);
     }
}    
     
void DeletaAluno(Banco *B, int nrusp, int *erro) {
     int pos;
     if (EstaVazio(B))
        *erro=1;
        
     else {
          *erro=0;
          nrusp = B->itens[B->ini].info.Aluno.nrusp;
          pos=B->ini;
          B->ini=B->itens[B->ini].prox;
          if (B->ini==-1)
             B->fim=-1;
          freenode(B,&pos);
     }
}

