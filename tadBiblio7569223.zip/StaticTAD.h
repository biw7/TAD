//nro USP 7569223
#define TAM 1000

typedef struct{
        char nome [60];
        char email[60];
        long int nrusp;
        long int tel;
        }aluno;
typedef struct {
        char titulo [100];
        char autor [60];
        int isbn;
        char editora [60];
        int ano;
        int edicao;
        int ncopias;
        }livro;

typedef union{
        aluno Aluno;
        livro Livro;
        } elem;

typedef struct {
        elem info;
        int prox;
} no;

typedef struct {
        int ini, fim, primeiro_vazio;
        no itens[TAM];
} Banco;

void cadastraAluno (elem *a);
void cadastraLivro (elem *a);
void cria(Banco *B);
void getnode(Banco *B, int *pos);
int EstaVazio(Banco *B); 
int EstaCheio(Banco *B);
void inserir (Banco *B, elem *x, int *erro);
int retiraLivro (Banco *B,int isbn);
void retornaLivro (Banco *B,int isbn); 
void imprimeLivro (Banco *B,int isbn) ;
void freenode(Banco *B, int *pos);
void DeletaLivro(Banco *B, int isbn, int *erro);
void DeletaAluno(Banco *B, int nrusp, int *erro);
