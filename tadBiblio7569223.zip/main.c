//nro USP 7569223
#include <stdlib.h>
#include <stdio.h>

#include "StaticTAD.h"
//#include "DinamicTAD.h"




int main(int argc, char *argv[])
{
  int op,erro,ncopias,isbn,nrusp;
  elem a;
  Banco B;
  cria(&B);
  
  
do {         
printf ("1.Cadastra Aluno\n2.Cadastra Livro\n3.Empresta Livro (consulta)\n4.Retorna Livro\n5.Exclui Aluno\n6.Exclui Livro\n");
scanf ("%d", &op);             
switch (op) {
case 1:
cadastraAluno (&a);
inserir(&B,&a,&erro);
break;
case 2:
cadastraLivro (&a);
inserir(&B,&a,&erro);           
break;
case 3:
printf ("ISBN:");
scanf ("%d", &isbn);
ncopias = retiraLivro (&B,isbn);
if (ncopias == 0){ printf ("Entra Fila!\n"); break;}
else          
imprimeLivro (&B,isbn);
break;
case 4:
printf ("ISBN:");
scanf ("%d", &isbn);
retornaLivro (&B,isbn);
imprimeLivro (&B,isbn);
break;   
case 5:
printf ("ISBN:");
scanf ("%d", &isbn);
DeletaLivro(&B,isbn,&erro);
break;     
case 6:
printf ("NRUSP:");
scanf ("%d", &nrusp);
DeletaAluno(&B, nrusp, &erro);
break;     
       }
} while (op!=0);    

  system("PAUSE");	
  return 0;
}
